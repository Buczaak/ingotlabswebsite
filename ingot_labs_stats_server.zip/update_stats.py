#!/usr/bin/env python3
"""Ingot Labs: aktualizacja stats.json (uruchamiaj z crona co ~30 min).

Zrodla:
  - odwiedziny: logi dostepu Caddy (JSON), bez cookies, IP tylko jako skrot dzienny
  - Modrinth: publiczne API (bez klucza)
  - CurseForge: oficjalne API (darmowy klucz)
  - YouTube: oficjalne API (darmowy klucz); X / Instagram / TikTok: wartosci reczne z configu
Kazde zrodlo dziala osobno: gdy jedno zawiedzie, zostaje poprzednia wartosc.
"""
import hashlib, json, os, re, secrets, sys, urllib.parse, urllib.request
from datetime import datetime, timedelta, timezone
from zoneinfo import ZoneInfo

CFG_PATH = sys.argv[1] if len(sys.argv) > 1 else '/opt/ingotlabs/stats_config.json'
UA = 'IngotLabs-Stats/1.0'
BOT = re.compile(r'bot|crawl|spider|slurp|preview|monitor|uptime|curl|wget|python|headless|facebookexternalhit|lighthouse', re.I)
KEEP_DAYS = 400

def jload(path, default):
    try:
        with open(path, encoding='utf-8') as f: return json.load(f)
    except Exception: return default

def http_json(url, headers=None, timeout=15):
    req = urllib.request.Request(url, headers={'User-Agent': UA, **(headers or {})})
    with urllib.request.urlopen(req, timeout=timeout) as r: return json.load(r)

def log(msg): print(datetime.now().strftime('%Y-%m-%d %H:%M:%S'), msg, flush=True)

# ------------------------------------------------------------------ visits
def update_visits(cfg, state, tz):
    path = cfg.get('access_log')
    host = (cfg.get('site_host') or '').lower()
    days = state.setdefault('days', {})
    last_ts = state.get('last_ts', 0.0)
    max_ts = last_ts
    if path and os.path.exists(path):
        with open(path, encoding='utf-8', errors='replace') as f:
            for line in f:
                try: e = json.loads(line)
                except Exception: continue
                ts = e.get('ts');  req = e.get('request') or {}
                if ts is None or ts <= last_ts: continue
                max_ts = max(max_ts, ts)
                if req.get('method') != 'GET' or e.get('status') != 200: continue
                if host and (req.get('host') or '').lower().split(':')[0] != host: continue
                uri = (req.get('uri') or '/').split('?')[0]
                if uri not in ('/', '/index.html'): continue
                ua = ((req.get('headers') or {}).get('User-Agent') or [''])[0]
                if not ua or BOT.search(ua): continue
                ip = req.get('client_ip') or req.get('remote_ip') or ''
                day = datetime.fromtimestamp(ts, tz).strftime('%Y-%m-%d')
                d = days.setdefault(day, {'views': 0, 'uniques': 0})
                d['views'] += 1
                if 'salt' not in d and 'hashes' not in d:
                    d['salt'] = secrets.token_hex(8); d['hashes'] = []
                if 'hashes' in d:
                    h = hashlib.sha256((d['salt'] + ip + ua).encode()).hexdigest()[:16]
                    if h not in d['hashes']:
                        d['hashes'].append(h); d['uniques'] = len(d['hashes'])
        state['last_ts'] = max_ts
    today = datetime.now(tz).date()
    for day in list(days):
        dd = datetime.strptime(day, '%Y-%m-%d').date()
        if (today - dd).days > KEEP_DAYS: del days[day]; continue
        if (today - dd).days >= 2:       # starsze dni: zapominamy skroty i sol
            days[day].pop('hashes', None); days[day].pop('salt', None)
    daily = []
    for i in range(29, -1, -1):
        day = (today - timedelta(days=i)).strftime('%Y-%m-%d')
        d = days.get(day, {})
        daily.append({'d': day, 'u': d.get('uniques', 0), 'v': d.get('views', 0)})
    td = days.get(today.strftime('%Y-%m-%d'), {})
    return {
        'total_views': sum(d.get('views', 0) for d in days.values()),
        'total_unique': sum(d.get('uniques', 0) for d in days.values()),
        'today_unique': td.get('uniques', 0),
        'daily': daily,
    }

# ------------------------------------------------------------------ downloads
def modrinth(slug):
    d = http_json('https://api.modrinth.com/v2/project/' + urllib.parse.quote(slug))
    return int(d['downloads'])

def curseforge(mod_id, key):
    d = http_json('https://api.curseforge.com/v1/mods/%s' % mod_id, {'x-api-key': key, 'Accept': 'application/json'})
    return int(d['data']['downloadCount'])

def youtube(channel_id, key):
    q = urllib.parse.urlencode({'part': 'statistics', 'id': channel_id, 'key': key})
    d = http_json('https://www.googleapis.com/youtube/v3/channels?' + q)
    st = d['items'][0]['statistics']
    if st.get('hiddenSubscriberCount'): return None
    return int(st['subscriberCount'])

def main():
    cfg = jload(CFG_PATH, None)
    if not cfg: log('brak configu: %s' % CFG_PATH); sys.exit(1)
    out_path = cfg.get('output', '/var/www/ingotlabs/stats.json')
    prev = jload(out_path, {})
    state_path = cfg.get('state', '/opt/ingotlabs/state.json')
    state = jload(state_path, {})
    tz = ZoneInfo(cfg.get('timezone', 'Europe/Warsaw'))
    out = {'updated': datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')}

    # visits
    try: out['visits'] = update_visits(cfg, state, tz)
    except Exception as e:
        log('visits: blad %r' % e); out['visits'] = prev.get('visits', {})

    # social
    manual = cfg.get('social_manual', {})
    prev_soc = {s['id']: s.get('followers') for s in prev.get('social', [])}
    soc = []
    for pid in ('youtube', 'tiktok', 'instagram', 'x'):
        val = manual.get(pid)
        if pid == 'youtube' and cfg.get('youtube_api_key') and cfg.get('youtube_channel_id'):
            try: val = youtube(cfg['youtube_channel_id'], cfg['youtube_api_key'])
            except Exception as e:
                log('youtube: blad %r' % e); val = prev_soc.get(pid, val)
        soc.append({'id': pid, 'followers': val})
    out['social'] = soc

    # projects
    prev_proj = {p['name']: {pl['id']: pl.get('downloads') for pl in p.get('platforms', [])} for p in prev.get('projects', [])}
    projects = []
    for p in cfg.get('projects', []):
        plats = []
        if p.get('modrinth_slug'):
            old = prev_proj.get(p['name'], {}).get('modrinth')
            try: n = modrinth(p['modrinth_slug'])
            except Exception as e: log('modrinth %s: blad %r' % (p['name'], e)); n = old
            plats.append({'id': 'modrinth', 'name': 'Modrinth', 'downloads': n,
                          'url': p.get('modrinth_url') or 'https://modrinth.com/project/' + p['modrinth_slug']})
        if p.get('curseforge_id') and cfg.get('curseforge_api_key'):
            old = prev_proj.get(p['name'], {}).get('curseforge')
            try: n = curseforge(p['curseforge_id'], cfg['curseforge_api_key'])
            except Exception as e: log('curseforge %s: blad %r' % (p['name'], e)); n = old
            plats.append({'id': 'curseforge', 'name': 'CurseForge', 'downloads': n, 'url': p.get('curseforge_url', '')})
        elif p.get('curseforge_manual') is not None:
            plats.append({'id': 'curseforge', 'name': 'CurseForge', 'downloads': p['curseforge_manual'], 'url': p.get('curseforge_url', '')})
        projects.append({'name': p['name'], 'tag': p.get('tag', ''), 'platforms': plats})
    out['projects'] = projects

    # zapis atomowy
    tmp = out_path + '.tmp'
    with open(tmp, 'w', encoding='utf-8') as f: json.dump(out, f, ensure_ascii=False, indent=1)
    os.chmod(tmp, 0o644); os.replace(tmp, out_path)
    tmp = state_path + '.tmp'
    os.makedirs(os.path.dirname(state_path), exist_ok=True)
    with open(tmp, 'w', encoding='utf-8') as f: json.dump(state, f)
    os.chmod(tmp, 0o600); os.replace(tmp, state_path)
    log('ok: visitors=%s views=%s' % (out['visits'].get('total_unique'), out['visits'].get('total_views')))

if __name__ == '__main__':
    main()
