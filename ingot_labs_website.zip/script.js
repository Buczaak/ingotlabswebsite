/* ============ EDIT YOUR LINKS HERE ============
   Leave a link empty ("") and its button disappears.
   For email use "mailto:you@example.com".                */
const LINKS = {
  modrinth:   "https://modrinth.com/",
  curseforge: "https://www.curseforge.com/minecraft",
  youtube:    "",
  x:          "",
  github:     "",
  discord:    "",
  email:      ""
};

const I18N = {
  en: {
    nav_build:"What we build", nav_projects:"Projects", nav_about:"About", nav_contact:"Contact",
    hero_title:"Economy plugins & mods for Minecraft",
    hero_lead:"We build tools that give players a reason to earn, invest and keep coming back to your server.",
    btn_modrinth:"Get WebMarket on Modrinth", chip_mods:"Mods soon",
    build_eyebrow:"WHAT WE BUILD", build_title:"Tools that make server economies fun",
    c1_t:"Markets & trading", c1_p:"Live prices, candlestick charts and limit orders. Players trade in the game and on the web.",
    c2_t:"Custom currencies", c2_p:"Your own coins with your own rules, added on the fly without a server restart.",
    c3_t:"Events & rankings", c3_p:"Bull and bear events with your own announcements, plus leaderboards that keep players competing.",
    proj_eyebrow:"FIRST RELEASE",
    wm_lead:"A crypto exchange with its own website for your Minecraft server. Players log in with a one-time code from the game, deposit in-game money, trade, and withdraw their profit back.",
    feat_t:"Highlights",
    f1:"Live candlestick charts, limit orders and a leaderboard of the richest players",
    f2:"Custom coins and custom events, no server restart",
    f3:"English and Polish website, switchable in one click",
    f4:"Edit chat messages and player accounts from the admin panel",
    f5:"Paper 1.21.4, Vault support, Java 21",
    btn_video:"Watch the video",
    soon_t:"More plugins and mods on the way", soon_p:"Mods are next. Follow along to see what we cook up in the lab.",
    about_eyebrow:"ABOUT", about_title:"An indie lab for Minecraft economies",
    about_p:"Ingot Labs makes economy plugins, and soon mods, for Minecraft. Every update is shaped by player and server-owner feedback, so if you have a bug or an idea, we want to hear it.",
    contact_eyebrow:"FIND US", contact_title:"Follow, download, say hi", link_email:"Email",
    legal:"Not an official Minecraft product. Not approved by or associated with Mojang or Microsoft."
  },
  pl: {
    nav_build:"Co tworzymy", nav_projects:"Projekty", nav_about:"O nas", nav_contact:"Kontakt",
    hero_title:"Pluginy i mody ekonomiczne do Minecrafta",
    hero_lead:"Tworzymy narzędzia, które dają graczom powód, żeby zarabiać, inwestować i wracać na Twój serwer.",
    btn_modrinth:"Pobierz WebMarket na Modrinth", chip_mods:"Mody wkrótce",
    build_eyebrow:"CO TWORZYMY", build_title:"Narzędzia, dzięki którym ekonomia serwera jest ciekawa",
    c1_t:"Rynki i handel", c1_p:"Ceny na żywo, wykresy świecowe i zlecenia limit. Gracze handlują w grze i w przeglądarce.",
    c2_t:"Własne waluty", c2_p:"Własne coiny z własnymi zasadami, dodawane w locie bez restartu serwera.",
    c3_t:"Eventy i rankingi", c3_p:"Eventy hossy i bessy z własnymi ogłoszeniami oraz rankingi, które napędzają rywalizację.",
    proj_eyebrow:"PIERWSZE WYDANIE",
    wm_lead:"Giełda kryptowalut z własną stroną dla Twojego serwera Minecraft. Gracze logują się jednorazowym kodem z gry, wpłacają pieniądze z gry, handlują i wypłacają zysk z powrotem.",
    feat_t:"Najważniejsze",
    f1:"Wykresy świecowe na żywo, zlecenia limit i ranking najbogatszych graczy",
    f2:"Własne coiny i własne eventy, bez restartu serwera",
    f3:"Strona po angielsku i po polsku, przełączana jednym kliknięciem",
    f4:"Edycja wiadomości czatu i kont graczy z panelu admina",
    f5:"Paper 1.21.4, wsparcie Vault, Java 21",
    btn_video:"Obejrzyj film",
    soon_t:"Kolejne pluginy i mody w drodze", soon_p:"Następne będą mody. Śledź nas, żeby zobaczyć, co powstaje w laboratorium.",
    about_eyebrow:"O NAS", about_title:"Niezależne laboratorium ekonomii w Minecrafcie",
    about_p:"Ingot Labs tworzy pluginy ekonomiczne, a wkrótce także mody, do Minecrafta. Każda aktualizacja powstaje na podstawie opinii graczy i właścicieli serwerów, więc jeśli masz błąd albo pomysł, napisz do nas.",
    contact_eyebrow:"ZNAJDŹ NAS", contact_title:"Obserwuj, pobieraj, napisz", link_email:"E-mail",
    legal:"To nie jest oficjalny produkt Minecraft. Brak zatwierdzenia i powiązania z Mojang lub Microsoft."
  }
};

function setLang(l){
  const d = I18N[l] || I18N.en;
  document.documentElement.lang = l;
  document.querySelectorAll('[data-i18n]').forEach(el=>{ if(d[el.dataset.i18n]) el.textContent = d[el.dataset.i18n]; });
  document.querySelectorAll('.lang button').forEach(b=>b.classList.toggle('on', b.dataset.lang===l));
  document.title = l==='pl' ? 'Ingot Labs | Pluginy i mody ekonomiczne do Minecrafta' : 'Ingot Labs | Economy plugins & mods for Minecraft';
  try{ localStorage.setItem('il_lang', l); }catch(e){}
}
document.querySelectorAll('.lang button').forEach(b=>b.addEventListener('click',()=>setLang(b.dataset.lang)));

document.querySelectorAll('[data-link]').forEach(a=>{
  const u = LINKS[a.dataset.link];
  if(u){ a.href = u; if(u.startsWith('mailto:')){ a.removeAttribute('target'); } } else { a.hidden = true; }
});
document.getElementById('yr').textContent = new Date().getFullYear();

let start = 'en';
try{ start = localStorage.getItem('il_lang') || ((navigator.language||'').toLowerCase().startsWith('pl') ? 'pl' : 'en'); }catch(e){ start = (navigator.language||'').toLowerCase().startsWith('pl') ? 'pl' : 'en'; }
setLang(start);

/* ===== pixel candlestick background ===== */
(function(){
  const c = document.getElementById('bg'); if(!c) return;
  const ctx = c.getContext('2d');
  const U = 10;                       // pixel unit
  let W, H, cols, candles, off = 0;
  const reduce = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
  function rnd(seed){ let s = seed; return ()=> (s = (s*16807)%2147483647)/2147483647; }
  function build(){
    W = c.width = innerWidth; H = c.height = innerHeight;
    const r = rnd(7), n = Math.ceil(W/(U*3))+60; let v = H*0.62; candles = [];
    for(let i=0;i<n;i++){
      const o=v, cl=Math.min(H*0.85,Math.max(H*0.35, v+(r()-0.5)*U*9 - U*0.8));
      candles.push({o, c:cl, hi:Math.min(o,cl)-r()*U*3, lo:Math.max(o,cl)+r()*U*3}); v=cl;
    }
    draw();
  }
  function draw(){
    ctx.clearRect(0,0,W,H);
    const step = U*3, n = candles.length, shift = Math.floor(off)%(step);
    const first = Math.floor(off/step);
    for(let i=0;i<Math.ceil(W/step)+1;i++){
      const k = candles[(first+i)%n], x = i*step - shift;
      const up = k.c < k.o; ctx.fillStyle = up ? 'rgba(47,224,138,.13)' : 'rgba(255,90,90,.11)';
      const q = y=>Math.round(y/U)*U;
      ctx.fillRect(x+U, q(k.hi), U, Math.max(U,q(k.lo)-q(k.hi)));
      ctx.fillRect(x, q(Math.min(k.o,k.c)), U*3-U, Math.max(U, q(Math.max(k.o,k.c))-q(Math.min(k.o,k.c))));
    }
  }
  function tick(){ off += 0.25; draw(); requestAnimationFrame(tick); }
  addEventListener('resize', build); build();
  if(!reduce) requestAnimationFrame(tick);
})();
