/* ============ EDIT YOUR LINKS HERE ============
   Leave a link empty ("") and its button disappears.
   For email use "mailto:you@example.com".                */
const LINKS = {
  modrinth:   "https://modrinth.com/",
  curseforge: "https://www.curseforge.com/minecraft",
  youtube:    "",
  x:          "",
  instagram:  "",
  tiktok:     "",
  github:     "",
  discord:    "",
  email:      ""
};

const I18N = {
  en: {
    privacy_link:"Privacy", privacy_more:"Details",
    nav_stats:"Stats", stats_eyebrow:"LIVE STATS", stats_title:"Ingot Labs in numbers",
    stats_lead:"Visits, community and downloads, updated automatically.",
    st_visits:"Website visits", st_visitors:"Visitors", st_views:"Page views", st_today:"Today", st_last30:"Last 30 days",
    st_community:"Community", st_followers:"followers", st_subscribers:"subscribers",
    st_downloads:"Downloads by project", st_total:"Total", st_updated:"Updated", st_nodata:"No data yet", st_dl:"downloads",
    st_privacy:"Visit counter is privacy-friendly: no cookies, no tracking scripts. Visitors are counted once per day.",
    nav_build:"What we build", nav_projects:"Projects", nav_about:"About", nav_contact:"Contact",
    hero_title:"Economy plugins & mods for Minecraft",
    hero_lead:"We build tools that give players a reason to earn, invest and keep coming back to your server.",
    btn_modrinth:"Get WebMarket on Modrinth", chip_mods:"Mods soon",
    build_eyebrow:"WHAT WE BUILD", build_title:"Tools that make server economies fun",
    c1_t:"Markets & trading", c1_p:"Live prices, candlestick charts and limit orders. Players trade in the game and on the web.",
    c2_t:"Custom currencies", c2_p:"Your own coins with your own rules, added on the fly without a server restart.",
    c3_t:"Events & rankings", c3_p:"Bull and bear events with your own announcements, plus leaderboards that keep players competing.",
    proj_eyebrow:"FIRST RELEASE",
    wm_lead:"A crypto exchange with its own website for your Minecraft server. Players log in with a one-time code from the game, deposit in-game money, trade, and withdraw their profit back.",
    feat_t:"Highlights",
    f1:"Live candlestick charts, limit orders and a leaderboard of the richest players",
    f2:"Custom coins and custom events, no server restart",
    f3:"English and Polish website, switchable in one click",
    f4:"Edit chat messages and player accounts from the admin panel",
    f5:"Paper 1.21.4, Vault support, Java 21",
    btn_video:"Watch the video",
    soon_t:"More plugins and mods on the way", soon_p:"Mods are next. Follow along to see what we cook up in the lab.",
    about_eyebrow:"ABOUT", about_title:"An indie lab for Minecraft economies",
    about_p:"Ingot Labs makes economy plugins, and soon mods, for Minecraft. Every update is shaped by player and server-owner feedback, so if you have a bug or an idea, we want to hear it.",
    contact_eyebrow:"FIND US", contact_title:"Follow, download, say hi", link_email:"Email",
    legal:"Not an official Minecraft product. Not approved by or associated with Mojang or Microsoft."
  },
  pl: {
    privacy_link:"Prywatność", privacy_more:"Szczegóły",
    nav_stats:"Statystyki", stats_eyebrow:"STATYSTYKI NA ŻYWO", stats_title:"Ingot Labs w liczbach",
    stats_lead:"Odwiedziny, społeczność i pobrania, aktualizowane automatycznie.",
    st_visits:"Odwiedziny strony", st_visitors:"Odwiedzający", st_views:"Wyświetlenia", st_today:"Dziś", st_last30:"Ostatnie 30 dni",
    st_community:"Społeczność", st_followers:"obserwujących", st_subscribers:"subskrybentów",
    st_downloads:"Pobrania według projektu", st_total:"Razem", st_updated:"Zaktualizowano", st_nodata:"Brak danych", st_dl:"pobrań",
    st_privacy:"Licznik odwiedzin szanuje prywatność: bez cookies i skryptów śledzących. Odwiedzający są liczeni raz dziennie.",
    nav_build:"Co tworzymy", nav_projects:"Projekty", nav_about:"O nas", nav_contact:"Kontakt",
    hero_title:"Pluginy i mody ekonomiczne do Minecrafta",
    hero_lead:"Tworzymy narzędzia, które dają graczom powód, żeby zarabiać, inwestować i wracać na Twój serwer.",
    btn_modrinth:"Pobierz WebMarket na Modrinth", chip_mods:"Mody wkrótce",
    build_eyebrow:"CO TWORZYMY", build_title:"Narzędzia, dzięki którym ekonomia serwera jest ciekawa",
    c1_t:"Rynki i handel", c1_p:"Ceny na żywo, wykresy świecowe i zlecenia limit. Gracze handlują w grze i w przeglądarce.",
    c2_t:"Własne waluty", c2_p:"Własne coiny z własnymi zasadami, dodawane w locie bez restartu serwera.",
    c3_t:"Eventy i rankingi", c3_p:"Eventy hossy i bessy z własnymi ogłoszeniami oraz rankingi, które napędzają rywalizację.",
    proj_eyebrow:"PIERWSZE WYDANIE",
    wm_lead:"Giełda kryptowalut z własną stroną dla Twojego serwera Minecraft. Gracze logują się jednorazowym kodem z gry, wpłacają pieniądze z gry, handlują i wypłacają zysk z powrotem.",
    feat_t:"Najważniejsze",
    f1:"Wykresy świecowe na żywo, zlecenia limit i ranking najbogatszych graczy",
    f2:"Własne coiny i własne eventy, bez restartu serwera",
    f3:"Strona po angielsku i po polsku, przełączana jednym kliknięciem",
    f4:"Edycja wiadomości czatu i kont graczy z panelu admina",
    f5:"Paper 1.21.4, wsparcie Vault, Java 21",
    btn_video:"Obejrzyj film",
    soon_t:"Kolejne pluginy i mody w drodze", soon_p:"Następne będą mody. Śledź nas, żeby zobaczyć, co powstaje w laboratorium.",
    about_eyebrow:"O NAS", about_title:"Niezależne laboratorium ekonomii w Minecrafcie",
    about_p:"Ingot Labs tworzy pluginy ekonomiczne, a wkrótce także mody, do Minecrafta. Każda aktualizacja powstaje na podstawie opinii graczy i właścicieli serwerów, więc jeśli masz błąd albo pomysł, napisz do nas.",
    contact_eyebrow:"ZNAJDŹ NAS", contact_title:"Obserwuj, pobieraj, napisz", link_email:"E-mail",
    legal:"To nie jest oficjalny produkt Minecraft. Brak zatwierdzenia i powiązania z Mojang lub Microsoft."
  }
};

function setLang(l){
  const d = I18N[l] || I18N.en;
  document.documentElement.lang = l;
  document.querySelectorAll('[data-i18n]').forEach(el=>{ if(d[el.dataset.i18n]) el.textContent = d[el.dataset.i18n]; });
  document.querySelectorAll('.lang button').forEach(b=>b.classList.toggle('on', b.dataset.lang===l));
  document.title = l==='pl' ? 'Ingot Labs | Pluginy i mody ekonomiczne do Minecrafta' : 'Ingot Labs | Economy plugins & mods for Minecraft';
  try{ localStorage.setItem('il_lang', l); }catch(e){}
  if(window.__statsReady) renderStats(false);
}
document.querySelectorAll('.lang button').forEach(b=>b.addEventListener('click',()=>setLang(b.dataset.lang)));

document.querySelectorAll('[data-link]').forEach(a=>{
  const u = LINKS[a.dataset.link];
  if(u){ a.href = u; if(u.startsWith('mailto:')){ a.removeAttribute('target'); } } else { a.hidden = true; }
});
document.getElementById('yr').textContent = new Date().getFullYear();


/* ===== live stats (reads stats.json written by update_stats.py on the server) ===== */
const SOCIAL = [
  {id:'youtube',   name:'YouTube',   unit:'st_subscribers', badge:'YT', color:'#ff6b6b'},
  {id:'tiktok',    name:'TikTok',    unit:'st_followers',   badge:'TT', color:'#3ee6e0'},
  {id:'instagram', name:'Instagram', unit:'st_followers',   badge:'IG', color:'#ff8fd0'},
  {id:'x',         name:'X',         unit:'st_followers',   badge:'X',  color:'#f0f4ff'}
];
const DEFAULT_PROJECTS = [{name:'WebMarket', tag:'BETA', platforms:[{id:'modrinth',name:'Modrinth',downloads:null,url:''},{id:'curseforge',name:'CurseForge',downloads:null,url:''}]}];
let STATS = null;
const reduceMotion = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
const T = k => (I18N[document.documentElement.lang] || I18N.en)[k] || k;
function fmt(n){ if(n==null || isNaN(n)) return '—'; try{ return new Intl.NumberFormat(document.documentElement.lang==='pl'?'pl-PL':'en-US').format(n); }catch(e){ return String(n); } }
function setNum(el, to, animate){
  if(!el) return;
  if(to==null || isNaN(to) || !animate || reduceMotion){ el.textContent = fmt(to); el.dataset.v = to==null?'':to; return; }
  const t0 = performance.now(), dur = 900;
  (function step(now){ const k = Math.min(1,(now-t0)/dur), e = 1-Math.pow(1-k,3); el.textContent = fmt(Math.round(to*e)); if(k<1) requestAnimationFrame(step); })(t0);
}
function drawChart(daily){
  const c = document.getElementById('v-chart'); if(!c) return;
  const box = c.parentElement, ctx = c.getContext('2d'); ctx.clearRect(0,0,c.width,c.height);
  const data = (daily||[]).slice(-30);
  box.classList.toggle('empty', !data.length);
  if(!data.length) return;
  const max = Math.max(1, ...data.map(d=>d.u||0)), n = 30, U = 4, gap = 4;
  const bw = Math.floor((c.width - gap*(n-1)) / n);
  data.forEach((d,i)=>{
    const idx = n - data.length + i, x = idx*(bw+gap);
    const h = Math.max(U, Math.round(((d.u||0)/max)*(c.height-14)/U)*U);
    ctx.fillStyle = i===data.length-1 ? '#2fe08a' : '#ffc93c';
    ctx.fillRect(x, c.height-h, bw, h);
    ctx.fillStyle = 'rgba(0,0,0,.28)'; ctx.fillRect(x+bw-U, c.height-h, U, h);
  });
}
function renderStats(animate){
  const d = STATS || {}, v = d.visits || {};
  setNum(document.getElementById('v-visitors'), v.total_unique, animate);
  setNum(document.getElementById('v-views'),    v.total_views,  animate);
  setNum(document.getElementById('v-today'),    v.today_unique, animate);
  drawChart(v.daily);
  // community
  const wrap = document.getElementById('social'); wrap.textContent = '';
  const byId = {}; (d.social||[]).forEach(s=>{ byId[s.id]=s; });
  SOCIAL.forEach(p=>{
    const url = LINKS[p.id], el = document.createElement(url ? 'a' : 'div');
    el.className = 'soc'; el.style.setProperty('--c', p.color);
    if(url){ el.href = url; el.target = '_blank'; el.rel = 'noopener'; }
    const badge = document.createElement('div'); badge.className = 'badge'; badge.textContent = p.badge;
    const box = document.createElement('div'), num = document.createElement('b'), lab = document.createElement('span');
    lab.textContent = p.name + ' · ' + T(p.unit); box.append(num, lab); el.append(badge, box); wrap.append(el);
    setNum(num, (byId[p.id]||{}).followers, animate);
  });
  // downloads by project (list grows automatically when new projects appear in stats.json)
  const pw = document.getElementById('proj-stats'); pw.textContent = '';
  (d.projects && d.projects.length ? d.projects : DEFAULT_PROJECTS).forEach(p=>{
    const card = document.createElement('div'); card.className = 'pj';
    const h = document.createElement('h4'); h.textContent = p.name;
    if(p.tag){ const i = document.createElement('i'); i.textContent = p.tag; h.append(i); }
    const grid = document.createElement('div'); grid.className = 'pj-grid';
    let total = null;
    (p.platforms||[]).forEach(pl=>{
      const t = document.createElement(pl.url ? 'a' : 'div'); t.className = pl.url ? 'pj-t' : '';
      if(pl.url){ t.href = pl.url; t.target = '_blank'; t.rel = 'noopener'; }
      const b = document.createElement('b'), s = document.createElement('span');
      s.textContent = pl.name + ' · ' + T('st_dl'); t.append(b, s); grid.append(t);
      setNum(b, pl.downloads, animate);
      if(pl.downloads!=null) total = (total||0) + pl.downloads;
    });
    const tt = document.createElement('div'); tt.className = 'tot';
    const tb = document.createElement('b'), ts = document.createElement('span'); ts.textContent = T('st_total'); tt.append(tb, ts); grid.append(tt);
    setNum(tb, total, animate);
    card.append(h, grid); pw.append(card);
  });
  const up = document.getElementById('st-updated');
  if(up) up.textContent = d.updated ? (T('st_updated') + ': ' + new Date(d.updated).toLocaleString(document.documentElement.lang==='pl'?'pl-PL':'en-GB') + '. ') : '';
}
window.__statsReady = true;
fetch('stats.json', {cache:'no-store'}).then(r=>r.ok ? r.json() : null).then(j=>{ STATS = j; renderStats(true); }).catch(()=>renderStats(false));

let start = 'en';
try{ start = localStorage.getItem('il_lang') || ((navigator.language||'').toLowerCase().startsWith('pl') ? 'pl' : 'en'); }catch(e){ start = (navigator.language||'').toLowerCase().startsWith('pl') ? 'pl' : 'en'; }
setLang(start);

/* ===== pixel candlestick background ===== */
(function(){
  const c = document.getElementById('bg'); if(!c) return;
  const ctx = c.getContext('2d');
  const U = 10;                       // pixel unit
  let W, H, cols, candles, off = 0;
  const reduce = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
  function rnd(seed){ let s = seed; return ()=> (s = (s*16807)%2147483647)/2147483647; }
  function build(){
    W = c.width = innerWidth; H = c.height = innerHeight;
    const r = rnd(7), n = Math.ceil(W/(U*3))+60; let v = H*0.62; candles = [];
    for(let i=0;i<n;i++){
      const o=v, cl=Math.min(H*0.85,Math.max(H*0.35, v+(r()-0.5)*U*9 - U*0.8));
      candles.push({o, c:cl, hi:Math.min(o,cl)-r()*U*3, lo:Math.max(o,cl)+r()*U*3}); v=cl;
    }
    draw();
  }
  function draw(){
    ctx.clearRect(0,0,W,H);
    const step = U*3, n = candles.length, shift = Math.floor(off)%(step);
    const first = Math.floor(off/step);
    for(let i=0;i<Math.ceil(W/step)+1;i++){
      const k = candles[(first+i)%n], x = i*step - shift;
      const up = k.c < k.o; ctx.fillStyle = up ? 'rgba(47,224,138,.13)' : 'rgba(255,90,90,.11)';
      const q = y=>Math.round(y/U)*U;
      ctx.fillRect(x+U, q(k.hi), U, Math.max(U,q(k.lo)-q(k.hi)));
      ctx.fillRect(x, q(Math.min(k.o,k.c)), U*3-U, Math.max(U, q(Math.max(k.o,k.c))-q(Math.min(k.o,k.c))));
    }
  }
  function tick(){ off += 0.25; draw(); requestAnimationFrame(tick); }
  addEventListener('resize', build); build();
  if(!reduce) requestAnimationFrame(tick);
})();
