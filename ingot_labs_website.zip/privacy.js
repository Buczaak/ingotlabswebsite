(function(){
  var T = {en:{back:'Back to the website', title:'Privacy | Ingot Labs'}, pl:{back:'Wróć na stronę', title:'Prywatność | Ingot Labs'}};
  function set(l){
    document.documentElement.lang = l;
    document.querySelectorAll('[data-l]').forEach(function(a){ a.hidden = a.dataset.l !== l; });
    document.querySelectorAll('[data-t]').forEach(function(e){ e.textContent = T[l][e.dataset.t]; });
    document.querySelectorAll('.lang button').forEach(function(b){ b.classList.toggle('on', b.dataset.lang === l); });
    document.title = T[l].title;
    try{ localStorage.setItem('il_lang', l); }catch(e){}
  }
  document.querySelectorAll('.lang button').forEach(function(b){ b.addEventListener('click', function(){ set(b.dataset.lang); }); });
  document.getElementById('yr').textContent = new Date().getFullYear();
  var l = 'en';
  try{ l = localStorage.getItem('il_lang') || ((navigator.language||'').toLowerCase().indexOf('pl') === 0 ? 'pl' : 'en'); }catch(e){ l = (navigator.language||'').toLowerCase().indexOf('pl') === 0 ? 'pl' : 'en'; }
  set(l === 'pl' ? 'pl' : 'en');
})();
