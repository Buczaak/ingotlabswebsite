INGOT LABS: strona (statyczna, bez instalacji)

PODGLĄD NA KOMPUTERZE
- Dwuklik na index.html, albo w tym folderze: python -m http.server 8000  ->  http://localhost:8000

CO EDYTOWAĆ
- script.js, góra pliku: LINKS = linki do Modrinth, CurseForge, YouTube, X, GitHub, Discord, e-mail.
  Pusty link ("") = przycisk znika. E-mail wpisz jako "mailto:ty@domena.pl".
- script.js, I18N: wszystkie teksty po angielsku (en) i po polsku (pl).
- assets/: logo, avatar, zrzuty ekranu WebMarket (shot-*.jpg). Podmień pliki o tych samych nazwach.

PUBLIKACJA (później)
- Skopiuj cały folder na serwer, np. do /var/www/ingotlabs, i użyj dołączonego Caddyfile
  (albo wrzuć folder na Cloudflare Pages / GitHub Pages / Netlify).
