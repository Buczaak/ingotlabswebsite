INGOT LABS: strona (statyczna, bez instalacji)

PODGLĄD NA KOMPUTERZE
- Dwuklik na index.html, albo w tym folderze: python -m http.server 8000  ->  http://localhost:8000

CO EDYTOWAĆ
- script.js, góra pliku: LINKS = linki do Modrinth, CurseForge, YouTube, X, GitHub, Discord, e-mail.
  Pusty link ("") = przycisk znika. E-mail wpisz jako "mailto:ty@domena.pl".
- script.js, I18N: wszystkie teksty po angielsku (en) i po polsku (pl).
- assets/: logo, avatar, zrzuty ekranu WebMarket (shot-*.jpg). Podmień pliki o tych samych nazwach.

PUBLIKACJA (później)
- Skopiuj cały folder na serwer, np. do /var/www/ingotlabs, i użyj dołączonego Caddyfile
  (albo wrzuć folder na Cloudflare Pages / GitHub Pages / Netlify).

STATYSTYKI (sekcja "Stats")
- Strona czyta plik stats.json. Lokalnie (po dwukliku w index.html) pokaze "—", bo przegladarka blokuje
  wczytywanie plikow z dysku. Uruchom python -m http.server 8000, aby zobaczyc dzialanie.
- Aktualizacje liczb na serwerze: patrz INSTALL_STATS.txt (w ingot_labs_stats_server.zip).
- Przy kolejnych wgraniach strony uzyj: unzip -o ... -x stats.json (zeby nie wyzerowac liczb).
- script.js: w LINKS doszly instagram i tiktok (karty w sekcji Stats linkuja do profili).
